// Local database config
module.exports = {
  HOST: "localhost",
  USER: "root",
  PASSWORD: "",
  DB: "tejas",
};
